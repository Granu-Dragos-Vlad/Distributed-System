package Serviciu;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ServWeb {

    private static String inputText = "";

    public static void main(String[] args) {
        // Creare frame
        JFrame frame = new JFrame("Calculator Integrala");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Creare componente
        JTextArea inputArea = new JTextArea();
        JTextArea resultArea = new JTextArea();
        JButton calculateButton = new JButton("Calculeaza integrala");

        // Adaugam componentele la frame
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.add(inputArea);
        frame.add(calculateButton);
        frame.add(resultArea);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inputText = inputArea.getText();
                calculeazaIntegrala(resultArea);
            }
        });
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    private static void calculeazaIntegrala(JTextArea resultArea) {
        try {
            String appId = "5HUATK-J8VAVTGQVU";
            String apiUrl = "http://api.wolframalpha.com/v2/query?" +
                    "input=" + URLEncoder.encode("integrate "+inputText, "UTF-8") +
                    "&format=plaintext" +
                    "&output=JSON" +
                    "&appid=" + appId;

            // Creez obiectul URL
            URL url = new URL(apiUrl);

            // Deschidem conexiunea HTTP
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Obținem raspunsul
            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    if (inputLine.contains("plaintext")) {
                        String lin = inputLine.replaceAll("^\\s+", "");
                        String rezultat = lin.replaceAll("plaintext\":\"", "");
                        resultArea.setText(rezultat);
                        break; 
                    }
                }
                in.close();
            } else {
                resultArea.setText("Apel esuat" + responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
